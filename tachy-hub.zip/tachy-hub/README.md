# TachyHub
Next.js 14 + TypeScript + Tailwind. ECG tachyarrhythmia diagnosis, Holter reporting, image library, learning hub, knowledge base, references.
## Run
npm install && npm run dev
## GitHub + Vercel
git init && git add . && git commit -m "TachyHub" && git branch -M main
git remote add origin https://github.com/shivesh2334-ai/tachy-hub.git && git push -u origin main
Then Vercel → Add New Project → import repo → Deploy (vercel.json pins bom1).
